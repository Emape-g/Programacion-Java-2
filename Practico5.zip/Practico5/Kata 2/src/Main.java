import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Inventario inventario = new Inventario();


        inventario.agregarProducto(new Producto("001", CategoriaProducto.ELECTRONICA, 10, 1500.0,"Computadora"));
        inventario.agregarProducto(new Producto("002", CategoriaProducto.ROPA, 20, 45.0,"Remeras"));
        inventario.agregarProducto(new Producto("003", CategoriaProducto.ALIMENTOS, 100, 2.5,"Carne"));
        inventario.agregarProducto(new Producto("004", CategoriaProducto.HOGAR, 5, 300.0,"Mesa"));


        inventario.listarProductos();


        inventario.buscarProductoPorId("003");


        ArrayList<Producto> electronicos = inventario.filtrarPorCategoria(CategoriaProducto.ELECTRONICA);



        inventario.eliminarProducto("002");


        inventario.listarProductos();
    }
}
