import java.util.ArrayList;

public class Inventario {
    private ArrayList<Producto> productos;

    public Inventario() {

        this.productos = new ArrayList<Producto>();
    }
    public void agregarProducto(Producto p){

        productos.add(p);
    }
    public void listarProductos(){
        for (Producto p: productos){
            System.out.println(p);
        }
    }
    public void buscarProductoPorId(String id){
        for (Producto p:productos){
            if(p.getId().equals(id)){
                System.out.println("El producto que buscas es " +p);

            }


        }
    }
    public void eliminarProducto(String id) {
        for (int i = productos.size() - 1; i >= 0; i--) {
            if (productos.get(i).getId().equals(id)) {
                Producto eliminado = productos.remove(i); // ✅ eliminación segura
                System.out.println("El producto eliminado es: " + eliminado);
                break;
            }
        }
    }

    public void actualizarStock(String id, int nuevaCantidad) {
        for (Producto p : productos) {
            if (p.getId().equals(id)) {
                p.setCantidad(nuevaCantidad);
                System.out.println("El producto  se actualizo " + p);

            }
        }
    }
    public ArrayList<Producto> filtrarPorCategoria(CategoriaProducto categoria){
        ArrayList<Producto> categoriaIguales = new ArrayList<>();
        for (Producto p : productos) {
            if (p.getCategoria().equals(categoria)) {
                categoriaIguales.add(p);


    }
        }
        return categoriaIguales;
    }
    @Override
    public String toString() {
        return "Inventario{" +
                "productos=" + productos +
                '}';
    }
}
