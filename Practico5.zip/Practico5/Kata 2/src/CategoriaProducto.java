public enum CategoriaProducto {
    ALIMENTOS, ELECTRONICA, ROPA, HOGAR
}
