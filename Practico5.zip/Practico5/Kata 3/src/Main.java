public class Main {
    public static void main(String[] args) {
        Inventario inventario = new Inventario();

        // 1. Agregar cinco productos con diferentes categorías y nombre al final
        inventario.agregarProducto(new Producto("P1", CategoriaProducto.ELECTRONICA, 10, 1500, "Celular"));
        inventario.agregarProducto(new Producto("P2", CategoriaProducto.ROPA, 5, 800, "Camisa"));
        inventario.agregarProducto(new Producto("P3", CategoriaProducto.ALIMENTOS, 20, 200, "Caja de cereales"));
        inventario.agregarProducto(new Producto("P4", CategoriaProducto.HOGAR, 7, 1200, "Mesa"));
        inventario.agregarProducto(new Producto("P5", CategoriaProducto.HOGAR, 12, 3000, "Lampara"));

        // 2. Mostrar total de stock disponible
        inventario.obtenerTotalStock();

        // 3. Obtener producto con mayor stock
        inventario.obtenerProductoConMayorStock();

        // 4. Filtrar productos entre $1000 y $3000

        inventario.filtrarProductosPorPrecio(1000, 3000);

        // 5. Mostrar categorías disponibles
        inventario.mostrarCategoriasDisponibles();
    }
}
