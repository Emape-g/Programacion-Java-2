import java.util.ArrayList;

public class Inventario {
    private ArrayList<Producto> productos;

    public Inventario() {

        this.productos = new ArrayList<Producto>();
    }

    public void agregarProducto(Producto p) {

        productos.add(p);
    }

    public void listarProductos() {
        for (Producto p : productos) {
            System.out.println(p);
        }
    }

    public void buscarProductoPorId(String id) {
        for (Producto p : productos) {
            if (p.getId().equals(id)) {
                System.out.println("El producto que buscas es " + p);

            }


        }
    }

    public void eliminarProducto(String id) {
        for (int i = productos.size() - 1; i >= 0; i--) {
            if (productos.get(i).getId().equals(id)) {
                Producto eliminado = productos.remove(i); // ✅ eliminación segura
                System.out.println("El producto eliminado es: " + eliminado);
                break;
            }
        }
    }

    public void actualizarStock(String id, int nuevaCantidad) {
        for (Producto p : productos) {
            if (p.getId().equals(id)) {
                p.setCantidad(nuevaCantidad);
                System.out.println("El producto  se actualizo " + p);

            }
        }
    }

    public ArrayList<Producto> filtrarPorCategoria(CategoriaProducto categoria) {
        ArrayList<Producto> categoriaIguales = new ArrayList<>();
        for (Producto p : productos) {
            if (p.getCategoria().equals(categoria)) {
                categoriaIguales.add(p);


            }
        }
        return categoriaIguales;
    }

    public void obtenerTotalStock() {
        int sumatoria = 0;
        for (Producto p : productos) {
            sumatoria += p.getCantidad();
        }
        System.out.println("El stock total es: " + sumatoria);
    }


    public void obtenerProductoConMayorStock() {
        int maxStock = 0;
        for (Producto p : productos) {
            if (p.getCantidad() > 0 && maxStock < p.getCantidad()) {
                maxStock = p.getCantidad();
            }
        }
        System.out.println("La cantidad más alta de stock es: " + maxStock);
    }
    public ArrayList<Producto> filtrarProductosPorPrecio(double min, double max) {
        ArrayList<Producto> productosEnRango = new ArrayList<>();
        for (Producto p : productos) {
            if (p.getPrecio() >= min && p.getPrecio() <= max) {
                productosEnRango.add(p);
            }
        }
        System.out.println("Los productos en ese rango son "+productosEnRango);
        return productosEnRango;
    }
    public void mostrarCategoriasDisponibles() {
        System.out.println("Categorías disponibles:");
        for (CategoriaProducto categoria : CategoriaProducto.values()) {
            System.out.println("- " + categoria + ": " + categoria.getDescripcion());
        }
    }


    @Override
    public String toString() {
        return "Inventario{" +
                "productos=" + productos +
                '}';
    }
}

