import java.util.ArrayList;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
                Producto p1 = new Producto("1",CategoriaProducto.HOGAR,5,350000,"MESA");
        Producto p2 = new Producto("2",CategoriaProducto.ELECTRONICA,10,500000,"HELADERA");
        Producto p3 = new Producto("3",CategoriaProducto.ROPA,50,35000,"REMERA ROJA");
        Inventario i = new Inventario();
        i.agregarProducto(p1);
        i.agregarProducto(p2);
        i.agregarProducto(p3);
        System.out.println(p1.toString());
        System.out.println(" ");
        i.listarProductos();

    }
}