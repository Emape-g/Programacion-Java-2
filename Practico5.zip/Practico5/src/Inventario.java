import java.util.ArrayList;

public class Inventario {
    private ArrayList<Producto> productos;

    public Inventario() {
        this.productos = new ArrayList<Producto>();
    }
    public void agregarProducto(Producto p){
        productos.add(p);
    }
    public void listarProductos(){
        for (Producto p: productos){
            System.out.println(p);
        }
    }

    @Override
    public String toString() {
        return "Inventario{" +
                "productos=" + productos +
                '}';
    }
}
