import java.util.Date;

public class TicketSoporte {
    private static int contador = 0;
    private int id;
    private String descripcion;
    private EstadoDelTicket estadoDelTicket;
    private Date fechaCreacion;
    private Usuario usuario;
    private Tecnico tecnico;

    public TicketSoporte(String descripcion) {
        this.id = ++contador;
        this.descripcion = descripcion;
        this.fechaCreacion = new Date();
        this.estadoDelTicket = EstadoDelTicket.ABIERTO;
        this.tecnico  = null;
    }
    public void cerrarTicket(){
        this.estadoDelTicket = EstadoDelTicket.CERRADO;
    }
    public TicketSoporte(String descripcion, Usuario usuario) {
        this.id = ++contador;
        this.descripcion = descripcion;
        this.fechaCreacion = new Date();
        this.estadoDelTicket = EstadoDelTicket.ABIERTO;
        this.usuario = usuario;
        this.tecnico  = null;
    }

    public void asignarTecnico(Tecnico tecnico){

        this.tecnico = tecnico;
    }

    @Override
    public String toString() {
        return "TicketSoporte{" +
                "id=" + id +
                ", descripcion='" + descripcion + '\'' +
                ", estado=" + estadoDelTicket +
                ", fechaCreacion=" + fechaCreacion +
                ", usuario=" + (usuario != null ? usuario.getNombre() : "Sin asignar") +
                ", tecnico=" + (tecnico != null ? tecnico : "Sin asignar") +
                '}';
    }

    public int getId() {
        return id;
    }

    public Tecnico getTecnico() {
        return tecnico;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public EstadoDelTicket getEstadoDelTicket() {
        return estadoDelTicket;
    }

    public String getDescripcion() {
        return descripcion;
    }
}