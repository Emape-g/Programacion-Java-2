import java.util.ArrayList;
import java.util.List;

public class SistemaSoporte {
    private List<TicketSoporte> tickets;

    public SistemaSoporte() {
        tickets=new ArrayList<>();
    }
    public void crearTicket(String descripcion, Usuario usuario){
        TicketSoporte nuevo = new TicketSoporte(descripcion,usuario);
        tickets.add(nuevo);
    }

    public void asignarTecnico(int idTicket, Tecnico tecnico){
        for (TicketSoporte t :tickets){
            if(t.getId() == idTicket){
                t.asignarTecnico(tecnico);
                return;
            }
        }
    }
    public void mostrarTodosLosTickets(){
        for (TicketSoporte t :tickets){
            System.out.println("Estado del ticket " + t.getEstadoDelTicket());;
    }}
    @Override
    public String toString() {
        for (TicketSoporte t :tickets){return "SistemaSoporte{" +
                "tickets=" + tickets +
                '}';
    }
        return "";
    }
}
