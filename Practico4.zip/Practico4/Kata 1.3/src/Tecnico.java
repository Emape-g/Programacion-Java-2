public class Tecnico {
    private static int contador = 1;
    private int id;
    private String nombre;
    private String especialidad;

    public Tecnico( String especialidad, String nombre) {
        this.id = ++contador;
        this.especialidad = especialidad;
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    @Override
    public String toString() {
        return "Tecnico{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", especialidad='" + especialidad + '\'' +
                '}';
    }
}
