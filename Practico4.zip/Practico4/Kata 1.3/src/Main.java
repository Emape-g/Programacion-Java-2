//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        SistemaSoporte sistema = new SistemaSoporte();

        Usuario usuario1 = new Usuario("emma@gmail.com", "Emanuel Pérez");
        Usuario usuario2 = new Usuario("juli@correo.com", "Julia Ramírez");

        Tecnico tecnico1 = new Tecnico("Carlos López", "Redes");
        Tecnico tecnico2 = new Tecnico("Ana Torres", "Software");

        sistema.crearTicket("No tengo internet", usuario1);
        sistema.crearTicket("No inicia la computadora", usuario2);
        sistema.crearTicket("Error en sistema de gestión", usuario1);

        sistema.asignarTecnico(1, tecnico1);
        sistema.asignarTecnico(2, tecnico2);

        sistema.mostrarTodosLosTickets();

        System.out.println(sistema.toString());



    }
}