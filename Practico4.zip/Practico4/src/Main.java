//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
            TicketSoporte ts = new TicketSoporte("Esta mal cobrado");
            ts.cerrarTicket();
        System.out.println(ts.toString());
            TicketSoporte ts2 =new TicketSoporte("Esta bien cobrado");
            ts2.cerrarTicket();
        System.out.println(ts2.toString());
    }
}