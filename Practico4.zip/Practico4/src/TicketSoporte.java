import java.util.Date;

public class TicketSoporte {
    private static int contador = 0;
    private int id;
    private String descripcion;
    private EstadoDelTicket estadoDelTicket;
    private Date fechaCreacion;

    public TicketSoporte(String descripcion) {
        this.id = ++contador;
        this.descripcion = descripcion;
        this.fechaCreacion = new Date();
        this.estadoDelTicket = EstadoDelTicket.ABIERTO;
    }
    public void cerrarTicket(){
        this.estadoDelTicket = EstadoDelTicket.CERRADO;
    }

    @Override
    public String toString() {
        return "TicketSoporte{" +
                "id=" + id +
                ", descripcion='" + descripcion + '\'' +
                ", estadoDelTicket=" + estadoDelTicket +
                ", fechaCreacion=" + fechaCreacion +
                '}';
    }
}
