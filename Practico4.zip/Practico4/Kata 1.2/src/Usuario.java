public class Usuario {
    private  static int contador = 1000;
    private int id;
    private String nombre;
    private String email;

    public Usuario( String email, String nombre) {
        this.id = ++contador;
        this.email = email;
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
