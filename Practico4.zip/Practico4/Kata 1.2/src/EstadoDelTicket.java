public enum EstadoDelTicket {
    ABIERTO,EN_PROCESO,CERRADO
}
