//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
            Usuario u1 = new Usuario("abcdefg@gmial.com","abc");
            Usuario u2 = new Usuario("efghijk@gmail.com", "efg");

            TicketSoporte tsct = new TicketSoporte("Hubo un error en el cobro");
            TicketSoporte tsct1 = new TicketSoporte("Esta de mas una coca",u1);
        TicketSoporte tsct2 = new TicketSoporte("Esta bien cobrado",u2);
        tsct.cerrarTicket();
        System.out.println(tsct.toString());
        tsct1.asignarTecnico("Mario");
        tsct1.cerrarTicket();
        System.out.println(tsct1.toString());
        tsct2.cerrarTicket();
        System.out.println(tsct2.toString());//TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.

    }
}