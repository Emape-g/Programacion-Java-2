import java.time.LocalDate;

public abstract class Empleado {
    protected String DNI;
    protected String nombre;
    protected String apellido;
    protected int anioIngreso;

    public Empleado(String DNI, String nombre, String apellido, int anioIngreso) {
        this.DNI = DNI;
        this.nombre = nombre;
        this.apellido = apellido;
        this.anioIngreso = anioIngreso;
    }

    public abstract double getSalario();

    public String nombreCompleto() {
        return nombre + " " + apellido;
    }

    public int antiguedadEnAnios() {
        return LocalDate.now().getYear() - anioIngreso;
    }
}
