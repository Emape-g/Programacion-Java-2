public class Main {
    public static void main(String[] args) {
        Empresa empresa = new Empresa();

        empresa.agregarEmpleado(new EmpleadoSalarioFijo("123", "Juan", "Pérez", 2021, 50000));
        empresa.agregarEmpleado(new EmpleadoSalarioFijo("456", "Ana", "Gómez", 2018, 60000));
        empresa.agregarEmpleado(new EmpleadoAComision("789", "Luis", "Martínez", 2022, 30000, 15, 1500));
        empresa.agregarEmpleado(new EmpleadoAComision("101", "Carla", "Sánchez", 2023, 28000, 10, 1600));

        empresa.mostrarSalarios();

        Empleado mejor = empresa.empleadoConMasClientes();
        if (mejor != null) {
            System.out.println("Empleado con más clientes: " + mejor.nombreCompleto());
        }
    }
}
