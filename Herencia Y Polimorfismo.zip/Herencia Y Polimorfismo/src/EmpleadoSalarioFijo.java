public class EmpleadoSalarioFijo extends Empleado {
    private double sueldoBasico;

    private static final double PORC1 = 0.05;
    private static final double PORC2 = 0.10;
    private static final int ANIO1 = 2;
    private static final int ANIO2 = 5;

    public EmpleadoSalarioFijo(String DNI, String nombre, String apellido, int anioIngreso, double sueldoBasico) {
        super(DNI, nombre, apellido, anioIngreso);
        this.sueldoBasico = sueldoBasico;
    }

    @Override
    public double getSalario() {
        double adicional = 0;
        int antiguedad = antiguedadEnAnios();

        if (antiguedad >= ANIO2) {
            adicional = PORC2;
        } else if (antiguedad >= ANIO1) {
            adicional = PORC1;
        }

        return sueldoBasico * (1 + adicional);
    }
}
