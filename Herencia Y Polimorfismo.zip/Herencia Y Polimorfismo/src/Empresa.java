import java.util.ArrayList;

public class Empresa {
    private ArrayList<Empleado> empleados;

    public Empresa() {
        empleados = new ArrayList<>();
    }

    public void agregarEmpleado(Empleado e) {
        empleados.add(e);
    }

    public void mostrarSalarios() {
        for (Empleado e : empleados) {
            System.out.println(e.nombreCompleto() + " - Salario: $" + e.getSalario());
        }
    }

    public Empleado empleadoConMasClientes() {
        EmpleadoAComision mejor = null;

        for (Empleado e : empleados) {
            if (e instanceof EmpleadoAComision) {
                EmpleadoAComision ea = (EmpleadoAComision) e;
                if (mejor == null || ea.getCantClientesCaptados() > mejor.getCantClientesCaptados()) {
                    mejor = ea;
                }
            }
        }

        return mejor;
    }
}
